//
//  AppDelegate.h
//  CertificateVerify
//
//  Created by Luca on 28/5/15.
//  Copyright (c) 2015年 Luca. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

